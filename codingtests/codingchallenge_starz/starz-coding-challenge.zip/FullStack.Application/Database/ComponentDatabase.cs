﻿using FullStack.Domain;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FullStack.Application.Database
{
    public class ComponentDatabase
    {
        public static Task<IEnumerable<Component>> GetComponents()
        {
            var list = new List<Component>();

            for (int i = 0; i < 100; i++)
            {
                list.Add(new Component(i));
            }

            return Task.FromResult(list.AsEnumerable());
        }
    }
}
