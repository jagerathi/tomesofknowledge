import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-change',
  templateUrl: './change.component.html',
  styleUrls: ['./change.component.css']
})
export class ChangeComponent {

  private validStatuses: string[] = [
    'Created',
    'Uploaded',
    'Completed'
  ]

  constructor(private fb: FormBuilder) { }

  uploadForm = this.fb.group({
    id: [null, Validators.required],
    status: [null, Validators.required],
  });

  onSubmit() {
    // TODO Number 4 Call the UpdateComponent API
    console.warn(this.uploadForm.value);
  }    
}
